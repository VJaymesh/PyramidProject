$(function() {
    //    let master = function(base, char) {

    let topDownPyramid = function() {

        let base_num = $('#baseValue').val();
        //alert(  $('#baseValue').val());
        //alert( $('#char').val() );
        let hsMaster = 1;

        if ((base_num % 2) === 0) {
            $('#ansSection').empty("Empty");

            for (row = 1; row <= base_num; row *= 2) {
                for (h = row; h < base_num; h *= 2) { // or h++ gives same answer
                    $('#ansSection').append("\u00A0");
                }
                for (s = 1; s <= row; s++) {
                    $('#ansSection').append($(' #char').val());
                }

                $('#ansSection').append('<br>');
            }
        } else {
            $('#ansSection').html("Please, enter even number");

        }
    }; // end of function

    //  $('#baseValue').change(topDownPyramid);
    //  $('#char').change(topDownPyramid);

    $('input').change(topDownPyramid);

}); // end of onLoad function
